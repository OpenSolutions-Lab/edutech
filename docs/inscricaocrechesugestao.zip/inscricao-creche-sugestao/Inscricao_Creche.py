"""Inscrição Creche — protótipo do fluxo para a família, com sugestão de alocação.

Complementa o "Fila Unidade" (visão de quem opera na creche). Aqui é a ponta da
família: a inscrição que hoje acontece em https://matricula.rio/ , de forma
autônoma ou presencialmente na unidade escolar.

O que este protótipo demonstra:
  1. dados mínimos da criança e escolha da modalidade de inscrição;
  2. o critério de sugestão de alocação:
       • Proximidade  -> pede endereço + motivo (próprio / rede de apoio / trabalho);
       • Agilidade de alocação -> prioriza onde a concorrência do ano anterior
         (2025) foi menor, como indicação de alocação mais rápida;
  3. um mapa (OpenStreetMap) com as unidades sugeridas e uma lista ranqueada;
  4. montagem da LISTA DE ESCOLHAS: a inscrição exige exatamente 5 opções, em
     ordem de prioridade. A lista já começa com as 5 melhores sugestões; o
     responsável reordena, troca ou substitui unidades antes de enviar.

O modelo apenas ajuda na seleção. As vagas e o nº de inscritos exibidos são do
ano anterior (2025), simulados nesta amostra — não são dados do ano corrente
nem garantia de vaga. Ver inscricao/unidades.py.

Roda de forma independente do resto do repositório (ver README.md desta pasta):
    cd inscricao-creche-sugestao && streamlit run Inscricao_Creche.py
"""
from __future__ import annotations

import sys
from datetime import date, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import folium
import streamlit as st
from streamlit_folium import st_folium

from inscricao.geocode import geocodificar
from inscricao.unidades import (
    ANO_REFERENCIA,
    BAIRROS,
    NUM_OPCOES,
    POR_CODIGO,
    TOTAL_INSCRITOS_ANO_ANTERIOR,
    TOTAL_UNIDADES,
    TOTAL_VAGAS_ANO_ANTERIOR,
    UNIDADES,
    UnidadeRanqueada,
    centroide_bairro,
    grupamento_por_nascimento,
    haversine_km,
    ranquear,
)

COR_MARINHO = "#0B3B60"
CENTRO_RIO = (-22.9200, -43.4000)

MOTIVOS_ENDERECO = [
    "Endereço próprio (onde a criança mora)",
    "Endereço da rede de apoio (avós, familiar, vizinho que ajuda no dia a dia)",
    "Endereço de trabalho do responsável",
]

DISCLAIMER_2025 = (
    f"Vagas ofertadas e nº de inscritos são do ano anterior ({ANO_REFERENCIA}) e "
    "servem apenas como indicação para montar a lista — não são dados do ano "
    "corrente nem garantia de vaga."
)

st.set_page_config(page_title="Inscrição Creche | SME-Rio", layout="wide")

st.markdown(
    f"""
    <div style="background:{COR_MARINHO};padding:14px 20px;border-radius:6px;margin-bottom:18px;">
        <span style="color:white;font-size:1.4em;font-weight:600;">Prefeitura do Rio · Educação</span>
        <br><span style="color:#C9D9E8;font-size:0.95em;">Inscrição Creche — protótipo com sugestão de alocação</span>
    </div>
    """,
    unsafe_allow_html=True,
)

# --- estado -----------------------------------------------------------------
est = st.session_state
est.setdefault("etapa", 1)
est.setdefault("crianca", {})
est.setdefault("criterio", None)
est.setdefault("ref", None)          # (lat, lon)
est.setdefault("ref_rotulo", "")
est.setdefault("motivo_endereco", MOTIVOS_ENDERECO[0])
est.setdefault("lista", [])          # códigos de unidade, em ordem de prioridade


def selo_concorrencia(r) -> tuple[str, str]:
    ratio = r.candidatos_por_vaga
    if ratio <= 1.5:
        return (f"🟢 Sobrou vaga em {ANO_REFERENCIA}", "#1E8E4E")
    if ratio <= 3.0:
        return (f"🔵 Concorrência baixa em {ANO_REFERENCIA}", "#0B3B60")
    if ratio <= 6.0:
        return (f"🟡 Concorrência média em {ANO_REFERENCIA}", "#B8860B")
    return (f"⚪ Concorrência alta em {ANO_REFERENCIA}", "#8A99A8")


def selo_para(criterio: str, r) -> tuple[str, str]:
    if criterio == "proximidade" and r.distancia_km is not None:
        if r.distancia_km <= 1.5:
            return ("🟢 Bem perto", "#1E8E4E")
        if r.distancia_km <= 4.0:
            return ("🔵 Perto", "#0B3B60")
        return ("⚪ Mais distante", "#8A99A8")
    return selo_concorrencia(r)


def linha_2025(u) -> str:
    return (
        f"📅 {ANO_REFERENCIA}: **{u.vagas_ofertadas_ano_anterior}** vagas ofertadas · "
        f"**{u.inscritos_ano_anterior}** inscritos · "
        f"~**{u.candidatos_por_vaga_ano_anterior:.1f}** por vaga"
    )


def reiniciar() -> None:
    for chave in (
        "etapa", "crianca", "criterio", "ref", "ref_rotulo",
        "motivo_endereco", "lista", "lista_semeada", "ref_rotulo_input",
    ):
        est.pop(chave, None)
    est["etapa"] = 1


def adicionar_a_lista(codigo: str) -> None:
    if codigo not in est["lista"] and len(est["lista"]) < NUM_OPCOES:
        est["lista"].append(codigo)


def mover(i: int, delta: int) -> None:
    j = i + delta
    lst = est["lista"]
    if 0 <= j < len(lst):
        lst[i], lst[j] = lst[j], lst[i]


def distancia_ref(u) -> float | None:
    if not est["ref"]:
        return None
    return haversine_km(est["ref"][0], est["ref"][1], u.lat, u.lon)


# --- barra lateral ---------------------------------------------------------
PASSOS = ["A criança", "Critério de sugestão", "Sugestões", "Minha lista de escolhas", "Envio"]
with st.sidebar:
    st.markdown("### Etapas")
    for i, nome in enumerate(PASSOS, start=1):
        marca = "✅" if i < est["etapa"] else ("🔵" if i == est["etapa"] else "⚪")
        st.write(f"{marca} {i}. {nome}")
    st.divider()
    if st.button("Recomeçar", use_container_width=True):
        reiniciar()
        st.rerun()
    st.caption(
        f"Protótipo. Nenhum dado é enviado ou salvo. A inscrição exige exatamente "
        f"{NUM_OPCOES} opções de unidade, em ordem de prioridade. A inscrição "
        "oficial é em matricula.rio, de forma autônoma ou na unidade escolar. "
        + DISCLAIMER_2025
    )


# ==========================================================================
# ETAPA 1 — dados da criança + modalidade
# ==========================================================================
if est["etapa"] == 1:
    st.subheader("1. Quem vai ser inscrito")

    col1, col2 = st.columns(2)
    with col1:
        nome = st.text_input("Nome da criança", value=est["crianca"].get("nome", ""))
        nascimento = st.date_input(
            "Data de nascimento",
            value=est["crianca"].get("nascimento", date(2024, 3, 1)),
            min_value=date(2021, 1, 1),
            max_value=date.today(),
            format="DD/MM/YYYY",
        )
    with col2:
        responsavel = st.text_input(
            "Nome do responsável", value=est["crianca"].get("responsavel", "")
        )
        modalidade = st.radio(
            "Como está fazendo a inscrição?",
            ["Pela internet (autônoma)", "Presencialmente numa unidade escolar"],
            index=0,
        )

    grupamento = grupamento_por_nascimento(nascimento)
    st.info(
        f"Pela data de nascimento, a criança entra no grupamento **{grupamento}** "
        f"em março/2026."
    )

    if st.button("Continuar", type="primary"):
        if not nome.strip() or not responsavel.strip():
            st.error("Preencha o nome da criança e o nome do responsável.")
        else:
            est["crianca"] = {
                "nome": nome.strip(),
                "nascimento": nascimento,
                "responsavel": responsavel.strip(),
                "modalidade": modalidade,
                "grupamento": grupamento,
            }
            est["etapa"] = 2
            st.rerun()


# ==========================================================================
# ETAPA 2 — critério de sugestão
# ==========================================================================
elif est["etapa"] == 2:
    st.subheader("2. Como você quer que a gente sugira a creche?")

    criterio_rotulo = st.radio(
        "Critério da sugestão de alocação",
        ["Proximidade", "Agilidade de alocação"],
        captions=[
            "Quero a creche mais perto de um endereço que eu indicar.",
            "Quero ser alocado o mais rápido possível, mesmo que fique um pouco mais longe.",
        ],
        index=0 if est["criterio"] in (None, "proximidade") else 1,
    )
    est["criterio"] = "proximidade" if criterio_rotulo == "Proximidade" else "agilidade"

    st.divider()

    if est["criterio"] == "proximidade":
        st.markdown("**Endereço de referência**")
        col_end, col_btn = st.columns([4, 1])
        with col_end:
            endereco = st.text_input(
                "Endereço (rua, número, bairro)",
                value=est.get("ref_rotulo_input", ""),
                placeholder="Ex.: Rua Conde de Bonfim, 300, Tijuca",
                label_visibility="collapsed",
            )
        with col_btn:
            buscar = st.button("Localizar", use_container_width=True)

        if buscar and endereco.strip():
            est["ref_rotulo_input"] = endereco
            achado = geocodificar(endereco)
            if achado:
                est["ref"] = (achado["lat"], achado["lon"])
                est["ref_rotulo"] = achado["rotulo"]
            else:
                est["ref"] = None
                est["ref_rotulo"] = ""
                st.warning(
                    "Não consegui localizar esse endereço. Escolha o bairro de "
                    "referência abaixo."
                )

        bairro = st.selectbox("Ou escolha o bairro de referência", ["—"] + BAIRROS, index=0)
        if bairro != "—":
            centro = centroide_bairro(bairro)
            if centro:
                est["ref"] = centro
                est["ref_rotulo"] = f"Bairro: {bairro}"

        est["motivo_endereco"] = st.radio(
            "Qual é esse endereço?",
            MOTIVOS_ENDERECO,
            index=MOTIVOS_ENDERECO.index(est.get("motivo_endereco", MOTIVOS_ENDERECO[0])),
        )

        if est["ref"]:
            st.success(f"Referência definida — {est['ref_rotulo']}")
            previa = folium.Map(location=est["ref"], zoom_start=14, tiles="OpenStreetMap")
            folium.Marker(
                est["ref"], tooltip="Endereço de referência",
                icon=folium.Icon(color="blue", icon="home", prefix="fa"),
            ).add_to(previa)
            st_folium(previa, height=260, use_container_width=True, returned_objects=[])

    else:
        st.info(
            "Sem endereço obrigatório. Vamos ordenar as unidades pela **concorrência "
            f"do ano anterior ({ANO_REFERENCIA})** — quantos inscritos disputaram cada "
            "vaga no grupamento. Menos concorrência = indicação de alocação mais "
            "rápida. Se quiser, indique um bairro só para centralizar o mapa."
        )
        bairro = st.selectbox("Bairro (opcional)", ["—"] + BAIRROS, index=0)
        est["ref"] = centroide_bairro(bairro) if bairro != "—" else None
        est["ref_rotulo"] = f"Bairro: {bairro}" if bairro != "—" else ""

    st.divider()
    col_v, col_c = st.columns([1, 1])
    with col_v:
        if st.button("Voltar", use_container_width=True):
            est["etapa"] = 1
            st.rerun()
    with col_c:
        pode_avancar = est["criterio"] == "agilidade" or est["ref"] is not None
        if st.button("Ver sugestões", type="primary", use_container_width=True, disabled=not pode_avancar):
            est["etapa"] = 3
            st.rerun()
    if est["criterio"] == "proximidade" and est["ref"] is None:
        st.caption("Informe um endereço ou escolha um bairro para continuar.")


# ==========================================================================
# ETAPA 3 — sugestões + mapa
# ==========================================================================
elif est["etapa"] == 3:
    crianca = est["crianca"]
    grupamento = crianca["grupamento"]
    ranking = ranquear(est["criterio"], grupamento, est["ref"])

    # A inscrição exige NUM_OPCOES opções: a lista já começa preenchida com as
    # melhores sugestões, e o responsável ajusta a partir daí.
    if not est.get("lista_semeada"):
        est["lista"] = [r.unidade.codigo for r in ranking[:NUM_OPCOES]]
        est["lista_semeada"] = True

    titulo = "mais próximas" if est["criterio"] == "proximidade" else "com menos concorrência"
    st.subheader(f"3. Creches sugeridas ({titulo})")
    st.caption(
        f"Grupamento **{grupamento}** · critério **{est['criterio']}**"
        + (f" · referência: {est['ref_rotulo']}" if est["ref_rotulo"] else "")
    )
    st.caption(
        f"Base de indicação: {TOTAL_UNIDADES} unidades desta amostra, com "
        f"{TOTAL_VAGAS_ANO_ANTERIOR} vagas ofertadas e {TOTAL_INSCRITOS_ANO_ANTERIOR} "
        f"inscritos em {ANO_REFERENCIA}. {DISCLAIMER_2025}"
    )

    n_lista = len(est["lista"])
    barra = st.container(border=True)
    with barra:
        cb1, cb2 = st.columns([2, 1])
        completo = n_lista == NUM_OPCOES
        cor_n = "#1E8E4E" if completo else "#B8860B"
        cb1.markdown(
            f"**Minha lista de escolhas:** "
            f"<span style='color:{cor_n};font-weight:700'>{n_lista}/{NUM_OPCOES}</span> "
            + ("— pronta para enviar" if completo else "— a inscrição exige as 5"),
            unsafe_allow_html=True,
        )
        with cb2:
            if st.button(
                "Revisar e reordenar →", type="primary",
                use_container_width=True, disabled=not completo,
            ):
                est["etapa"] = 4
                st.rerun()
        st.caption(
            "A lista começou com as 5 melhores sugestões. Troque unidades removendo "
            "e adicionando; a ordem final você define na próxima etapa."
        )
        if n_lista != NUM_OPCOES and st.button("Restaurar as 5 sugestões"):
            est["lista"] = [r.unidade.codigo for r in ranking[:NUM_OPCOES]]
            st.rerun()

    col_mapa, col_lista = st.columns([1, 1])

    with col_mapa:
        centro = est["ref"] or CENTRO_RIO
        m = folium.Map(location=centro, zoom_start=14 if est["ref"] else 11, tiles="OpenStreetMap")
        if est["ref"]:
            folium.Marker(
                est["ref"], tooltip="Endereço de referência",
                icon=folium.Icon(color="blue", icon="home", prefix="fa"),
            ).add_to(m)
        else:
            lats = [u.lat for u in UNIDADES]
            lons = [u.lon for u in UNIDADES]
            m.fit_bounds([[min(lats), min(lons)], [max(lats), max(lons)]])

        for pos, r in enumerate(ranking):
            u = r.unidade
            if pos == 0:
                cor, icone = "green", "star"
            elif pos <= 4:
                cor, icone = "orange", "graduation-cap"
            else:
                cor, icone = "lightgray", "graduation-cap"
            dist = f"{r.distancia_km:.1f} km · " if r.distancia_km is not None else ""
            folium.Marker(
                (u.lat, u.lon),
                tooltip=f"{pos + 1}. {u.nome}",
                popup=folium.Popup(
                    f"<b>{u.nome}</b><br>{u.tipo} · CRE {u.cre}<br>{u.endereco}<br>"
                    f"{dist}{ANO_REFERENCIA}: {u.vagas_ofertadas_ano_anterior} vagas / "
                    f"{u.inscritos_ano_anterior} inscritos",
                    max_width=260,
                ),
                icon=folium.Icon(color=cor, icon=icone, prefix="fa"),
            ).add_to(m)

        st_folium(m, height=520, use_container_width=True, returned_objects=[])
        st.caption("⭐ 1ª sugestão · 🟧 próximas · Mapa © OpenStreetMap")

    with col_lista:
        for pos, r in enumerate(ranking[:8]):
            u = r.unidade
            selo = selo_para(est["criterio"], r)
            na_lista = u.codigo in est["lista"]

            with st.container(border=True):
                st.markdown(
                    f"**{pos + 1}. {u.nome}**  \n"
                    f"<span style='color:#5B7FA6'>{u.tipo} · CRE {u.cre} · {u.bairro}</span>",
                    unsafe_allow_html=True,
                )
                partes = []
                if r.distancia_km is not None:
                    partes.append(f"📍 **{r.distancia_km:.1f} km**")
                partes.append(
                    f"<span style='background:{selo[1]};color:white;padding:2px 8px;"
                    f"border-radius:10px;font-size:0.8em'>{selo[0]}</span>"
                )
                st.markdown(" · ".join(partes), unsafe_allow_html=True)
                st.markdown(linha_2025(u))
                st.caption(f"{u.endereco} · {r.motivo}")

                if na_lista:
                    ordem = est["lista"].index(u.codigo) + 1
                    ca, cb = st.columns([3, 1])
                    ca.success(f"✓ {ordem}ª opção na sua lista")
                    if cb.button("✕", key=f"rm3-{u.codigo}", help="Remover da lista", use_container_width=True):
                        est["lista"].remove(u.codigo)
                        st.rerun()
                else:
                    cheio = len(est["lista"]) >= NUM_OPCOES
                    if st.button(
                        "➕ Adicionar à minha lista",
                        key=f"add3-{u.codigo}",
                        use_container_width=True,
                        disabled=cheio,
                    ):
                        adicionar_a_lista(u.codigo)
                        st.rerun()
                    if cheio:
                        st.caption(
                            f"Lista com as {NUM_OPCOES} opções. Remova uma para trocar."
                        )

    st.divider()
    if st.button("Voltar"):
        est["etapa"] = 2
        st.rerun()


# ==========================================================================
# ETAPA 4 — montar / reordenar a lista de escolhas
# ==========================================================================
elif est["etapa"] == 4:
    st.subheader("4. Minha lista de escolhas")
    st.caption(
        f"A inscrição exige exatamente **{NUM_OPCOES} opções**, em ordem de "
        "prioridade — a **1ª opção** é a mais prioritária. Reordene com ↑ ↓, "
        "remova com ✕ e adicione outras unidades. " + DISCLAIMER_2025
    )

    n = len(est["lista"])
    if n < NUM_OPCOES:
        st.warning(
            f"Sua lista tem **{n}** de **{NUM_OPCOES}** opções obrigatórias. "
            f"Adicione mais {NUM_OPCOES - n} para poder enviar."
        )
    if not est["lista"]:
        if st.button("← Voltar às sugestões"):
            est["etapa"] = 3
            st.rerun()
        st.stop()

    col_mapa, col_lista = st.columns([1, 1])

    with col_mapa:
        unidades_lista = [POR_CODIGO[c] for c in est["lista"]]
        pontos = [(u.lat, u.lon) for u in unidades_lista]
        if est["ref"]:
            pontos.append(tuple(est["ref"]))
        centro_lista = (
            sum(p[0] for p in pontos) / len(pontos),
            sum(p[1] for p in pontos) / len(pontos),
        )
        m = folium.Map(location=list(centro_lista), zoom_start=13, tiles="OpenStreetMap")
        if est["ref"]:
            folium.Marker(
                est["ref"], tooltip="Endereço de referência",
                icon=folium.Icon(color="blue", icon="home", prefix="fa"),
            ).add_to(m)
        for i, u in enumerate(unidades_lista):
            folium.Marker(
                (u.lat, u.lon),
                tooltip=f"{i + 1}ª opção — {u.nome}",
                icon=folium.DivIcon(
                    icon_size=(28, 28),
                    icon_anchor=(14, 14),
                    html=(
                        f"<div style='background:{COR_MARINHO};color:#fff;border:2px solid #fff;"
                        "border-radius:50%;width:28px;height:28px;line-height:24px;text-align:center;"
                        "font-weight:700;font-family:sans-serif;box-shadow:0 1px 4px rgba(0,0,0,.4)'>"
                        f"{i + 1}</div>"
                    ),
                ),
            ).add_to(m)
        if len(pontos) > 1:
            lats = [p[0] for p in pontos]
            lons = [p[1] for p in pontos]
            m.fit_bounds([[min(lats), min(lons)], [max(lats), max(lons)]])
        st_folium(m, height=480, use_container_width=True, returned_objects=[])

    with col_lista:
        for i, codigo in enumerate(list(est["lista"])):
            u = POR_CODIGO[codigo]
            d = distancia_ref(u)
            with st.container(border=True):
                st.markdown(
                    f"**{i + 1}ª opção — {u.nome}**  \n"
                    f"<span style='color:#5B7FA6'>{u.tipo} · CRE {u.cre} · {u.bairro}</span>",
                    unsafe_allow_html=True,
                )
                partes = []
                if d is not None:
                    partes.append(f"📍 {d:.1f} km")
                partes.append(
                    f"{ANO_REFERENCIA}: {u.vagas_ofertadas_ano_anterior} vagas / "
                    f"{u.inscritos_ano_anterior} inscritos"
                )
                st.caption(" · ".join(partes))

                b1, b2, b3, _ = st.columns([1, 1, 1, 2])
                if b1.button("↑", key=f"up-{codigo}", help="Subir", use_container_width=True, disabled=i == 0):
                    mover(i, -1)
                    st.rerun()
                if b2.button("↓", key=f"down-{codigo}", help="Descer", use_container_width=True, disabled=i == len(est["lista"]) - 1):
                    mover(i, +1)
                    st.rerun()
                if b3.button("✕", key=f"rm-{codigo}", help="Remover da lista", use_container_width=True):
                    est["lista"].remove(codigo)
                    st.rerun()

        disponiveis = [
            u for u in sorted(UNIDADES, key=lambda x: x.nome)
            if u.codigo not in est["lista"]
        ]
        if len(est["lista"]) < NUM_OPCOES and disponiveis:
            st.markdown("**Adicionar outra unidade**")
            rotulos = {f"{u.nome} — {u.bairro} (CRE {u.cre})": u.codigo for u in disponiveis}
            escolhido = st.selectbox(
                "Unidade", ["—"] + list(rotulos), index=0, label_visibility="collapsed"
            )
            if escolhido != "—" and st.button("Adicionar à lista"):
                adicionar_a_lista(rotulos[escolhido])
                st.rerun()
        elif len(est["lista"]) == NUM_OPCOES:
            st.caption(f"Lista completa: {NUM_OPCOES}/{NUM_OPCOES} opções.")

    st.divider()
    completo = len(est["lista"]) == NUM_OPCOES
    cvolta, _, cenvia = st.columns([1, 1, 1])
    if cvolta.button("← Voltar às sugestões", use_container_width=True):
        est["etapa"] = 3
        st.rerun()
    if cenvia.button(
        "Enviar inscrição", type="primary", use_container_width=True, disabled=not completo
    ):
        est["etapa"] = 5
        st.rerun()
    if not completo:
        st.caption(f"O envio libera quando a lista tiver as {NUM_OPCOES} opções.")


# ==========================================================================
# ETAPA 5 — envio / confirmação
# ==========================================================================
elif est["etapa"] == 5:
    crianca = est["crianca"]
    unidades_lista = [POR_CODIGO[c] for c in est["lista"]]
    primeira = unidades_lista[0]
    protocolo = (
        f"{primeira.cre:02d}-2026-"
        f"{abs(hash(crianca['nome'] + primeira.codigo)) % 900000 + 100000}"
    )

    st.subheader("5. Inscrição enviada (protótipo)")
    st.success(f"Protocolo **{protocolo}** — guarde este número para acompanhar.")

    st.markdown(f"#### Você enviou as {len(unidades_lista)} opções, nesta ordem de prioridade:")
    for i, u in enumerate(unidades_lista, start=1):
        d = distancia_ref(u)
        extra = f" · {d:.1f} km da referência" if d is not None else ""
        with st.container(border=True):
            st.markdown(f"**{i}ª opção — {u.nome}**  \n{u.tipo} · CRE {u.cre} · {u.bairro}{extra}")
            st.caption(
                f"{u.endereco} · {ANO_REFERENCIA}: {u.vagas_ofertadas_ano_anterior} vagas "
                f"ofertadas / {u.inscritos_ano_anterior} inscritos"
            )

    st.markdown("#### Resumo da inscrição")
    resumo = {
        "Criança": crianca["nome"],
        "Responsável": crianca["responsavel"],
        "Grupamento (mar/2026)": crianca["grupamento"],
        "Modalidade": crianca["modalidade"],
        "Critério de sugestão": est["criterio"].capitalize(),
        "Endereço de referência": est["ref_rotulo"] or "—",
        "Motivo do endereço": (
            est["motivo_endereco"] if est["criterio"] == "proximidade" else "—"
        ),
        "Opções enviadas": str(len(unidades_lista)),
    }
    for campo, valor in resumo.items():
        c_campo, c_valor = st.columns([1, 2])
        c_campo.markdown(f"**{campo}**")
        c_valor.write(valor)

    st.caption(
        f"Gerado em {datetime.now():%d/%m/%Y %H:%M}. Protótipo — a inscrição oficial "
        "e a classificação por critérios de prioridade seguem em matricula.rio. "
        + DISCLAIMER_2025
    )

    cnova, cvolta = st.columns([1, 1])
    if cnova.button("Fazer nova inscrição", type="primary", use_container_width=True):
        reiniciar()
        st.rerun()
    if cvolta.button("Ajustar minha lista", use_container_width=True):
        est["etapa"] = 4
        st.rerun()
