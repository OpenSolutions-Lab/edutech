# Inscrição Creche — protótipo do fluxo da família (com sugestão de alocação)

Complementa o **Fila Unidade** (visão de quem opera na creche). Aqui é a ponta da
família: a inscrição que hoje acontece em <https://matricula.rio/>, de forma
autônoma ou presencialmente na unidade escolar.

> **Pasta independente.** Roda sozinha, sem depender do `src/` do resto do
> repositório. Tem o próprio `requirements.txt` e o próprio `.streamlit/`
> (tema com a fonte Poppins / cores do Manual de Marca SME 2025).

## Rodar

```sh
cd inscricao-creche-sugestao
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
streamlit run Inscricao_Creche.py
```

Precisa de internet: os *tiles* do mapa vêm do OpenStreetMap e a geocodificação
de endereço usa o Nominatim.

## Estrutura

```
inscricao-creche-sugestao/
├── Inscricao_Creche.py      # app Streamlit (as 5 etapas do fluxo)
├── inscricao/
│   ├── unidades.py          # amostra de unidades + base 2025 + ranqueamento
│   └── geocode.py           # endereço -> ponto no mapa (Nominatim)
├── .streamlit/config.toml   # tema SME (Poppins)
└── requirements.txt
```

## O que o protótipo mostra

1. **Dados mínimos da criança** + modalidade de inscrição (autônoma pela internet
   ou presencial na unidade). A data de nascimento define o grupamento.
2. **Critério da sugestão de alocação:**
   - **Proximidade** — abre campo de endereço (geocodificado no OpenStreetMap) e
     o *motivo* do endereço: próprio / rede de apoio / trabalho do responsável.
     Também aceita escolher só o bairro de referência.
   - **Agilidade de alocação** — sem endereço obrigatório; ordena pela
     **concorrência do ano anterior (2025)**: inscritos ÷ vagas ofertadas por
     unidade no grupamento. Menos concorrência = indicação de alocação mais
     rápida.
3. **Tela de sugestões:** mapa (Leaflet/OpenStreetMap) com o endereço de
   referência e as unidades ranqueadas, + lista de cards com distância, os
   números de 2025 (vagas ofertadas / inscritos / candidatos por vaga), o selo
   de concorrência e o "porquê" de cada sugestão. Mostra também os totais da
   base (nº de unidades, vagas e inscritos de 2025).
4. **Minha lista de escolhas:** a inscrição exige **exatamente 5 opções**, em
   ordem de prioridade. A lista já vem preenchida com as 5 melhores sugestões;
   o responsável **reordena** (↑ ↓), **remove** (✕) e **adiciona/substitui**
   outras unidades. O envio só libera com as 5 opções.
5. **Confirmação** com número de protocolo e a lista enviada (protótipo — nada
   é salvo).

## Dados das unidades

`inscricao/unidades.py` — amostra de ~30 creches e EDIs, recorte manual da
camada pública **"Escolas Municipais"** do DATA.RIO
(<https://www.data.rio/datasets/escolas-municipais>; campos CRE, Denominação,
Tipo, Latitude, Longitude). O serviço ArcGIS de origem
(`pgeo3.rio.rj.gov.br/arcgis/rest/services/Educacao/SME/MapServer/1`) estava
fora do ar (502) na construção — trocar a amostra pela base completa é só
repovoar `UNIDADES` a partir desse endpoint. O repositório também já tem
`data/raw/Bases IC_.../04_UnidadesEscolaresComEndereco.csv`, mas nessa extração
os campos de endereço/coordenada vêm quase todos `NULL`.

**`vagas_ofertadas_ano_anterior`** e **`inscritos_ano_anterior`** (2025) são
**simulados** (semente determinística por unidade). A ideia é usar a razão
histórica *inscritos ÷ vagas do ano anterior* como **indicação de concorrência**
para ajudar o responsável a montar a lista — **não é previsão, não é dado do ano
corrente e não é garantia de vaga**. A UI deixa isso explícito em todas as telas.
Em produção esses números viriam do histórico oficial da SME e do motor de fila
(`src/engine/queue_state.py`).

`NUM_OPCOES = 5` controla o nº obrigatório de opções da inscrição.

## Relação com o edital

Fecha o ciclo com o Fila Unidade: a família sinaliza a intenção (proximidade x
agilidade) na inscrição, e essa sinalização alimenta o mesmo motor que a unidade
opera. Não mexe em critério legal de classificação — a pontuação de prioridade
segue sendo a oficial; a sugestão só orienta *quais unidades escolher* no
formulário.
