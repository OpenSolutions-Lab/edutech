"""Geocodificação de endereço via Nominatim (OpenStreetMap).

Usado só no protótipo, para transformar o endereço digitado pela família em
um ponto no mapa. Se a chamada falhar (sem internet, limite de uso), a tela
cai para a seleção de bairro, que usa o centroide da amostra de unidades.
"""
from __future__ import annotations

import requests

_URL = "https://nominatim.openstreetmap.org/search"
_CABECALHO = {"User-Agent": "sme-rio-proto-inscricao-creche/0.1 (hackathon)"}

# Caixa aproximada do município do Rio de Janeiro (lon_min, lat_min, lon_max, lat_max)
_VIEWBOX = "-43.80,-23.10,-43.10,-22.74"


def geocodificar(endereco: str, timeout: float = 6.0) -> dict | None:
    """Retorna {'lat', 'lon', 'rotulo'} ou None."""
    consulta = endereco.strip()
    if not consulta:
        return None
    if "rio de janeiro" not in consulta.lower():
        consulta = f"{consulta}, Rio de Janeiro, RJ"
    try:
        resp = requests.get(
            _URL,
            params={
                "q": consulta,
                "format": "json",
                "limit": 1,
                "countrycodes": "br",
                "viewbox": _VIEWBOX,
                "bounded": 1,
                "addressdetails": 0,
            },
            headers=_CABECALHO,
            timeout=timeout,
        )
        resp.raise_for_status()
        dados = resp.json()
    except (requests.RequestException, ValueError):
        return None
    if not dados:
        return None
    item = dados[0]
    nome = item.get("display_name", consulta)
    rotulo = ", ".join(p.strip() for p in nome.split(",")[:3])
    return {
        "lat": float(item["lat"]),
        "lon": float(item["lon"]),
        "rotulo": rotulo,
    }
