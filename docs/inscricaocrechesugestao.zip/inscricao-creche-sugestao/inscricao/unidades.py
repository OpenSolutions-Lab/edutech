"""Amostra de unidades da SME-Rio (creches e EDIs) para o protótipo de inscrição.

Fonte da lista: recorte manual da camada pública "Escolas Municipais" do
DATA.RIO (campos CRE, Denominação, Tipo, Latitude, Longitude) —
https://www.data.rio/datasets/escolas-municipais . O serviço ArcGIS de origem
(pgeo3.rio.rj.gov.br) estava fora do ar no momento da construção, então aqui
vai uma amostra de ~30 unidades com coordenadas em nível de bairro.

`vagas_ofertadas_ano_anterior` e `inscritos_ano_anterior` NÃO são dado oficial —
são gerados de forma determinística (semente por unidade) para simular a base do
**ano anterior (2025)**: quantas vagas a unidade ofertou para o grupamento e
quantas crianças se inscreveram concorrendo a elas. A ideia é que a razão
inscritos ÷ vagas do ano anterior sirva de **indicação de concorrência** para
ajudar o responsável a montar a lista de escolhas — não é previsão nem dado do
ano corrente. Em produção esses números viriam do histórico oficial da SME e do
motor de fila (ver src/engine/queue_state.py).
"""
from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass
from datetime import date

# Início do ano letivo usado para calcular a idade / o grupamento da criança.
INICIO_ANO_LETIVO = date(2026, 3, 1)

# Ano da base histórica usada como indicação (sempre o ano anterior ao processo).
ANO_REFERENCIA = 2025

# A inscrição exige exatamente este número de opções de unidade (obrigatório).
NUM_OPCOES = 5


@dataclass(frozen=True)
class Unidade:
    codigo: str
    nome: str
    tipo: str  # "Creche Municipal" | "EDI"
    cre: int
    bairro: str
    endereco: str
    lat: float
    lon: float

    # --- base simulada do ANO ANTERIOR (2025) — não são dados reais ---------
    @property
    def _semente(self) -> int:
        return int(hashlib.md5(self.codigo.encode()).hexdigest()[:8], 16)

    @property
    def vagas_ofertadas_ano_anterior(self) -> int:
        """Vagas que a unidade ofertou para o grupamento em 2025 (simulado)."""
        return [6, 8, 10, 12, 14, 16, 20, 24, 30][self._semente % 9]

    @property
    def inscritos_ano_anterior(self) -> int:
        """Crianças inscritas concorrendo a essas vagas em 2025 (simulado)."""
        fator = 0.6 + (self._semente // 9 % 40) / 10.0  # 0,6x a 4,5x as vagas
        return max(1, round(self.vagas_ofertadas_ano_anterior * fator))

    @property
    def candidatos_por_vaga_ano_anterior(self) -> float:
        return self.inscritos_ano_anterior / max(self.vagas_ofertadas_ano_anterior, 1)

    @property
    def indicacao_concorrencia(self) -> str:
        """Rótulo qualitativo da concorrência de 2025."""
        r = self.candidatos_por_vaga_ano_anterior
        if r <= 1.5:
            return "sobrou vaga em 2025"
        if r <= 3.0:
            return "concorrência baixa em 2025"
        if r <= 6.0:
            return "concorrência média em 2025"
        return "concorrência alta em 2025"

    @property
    def grupamentos(self) -> list[str]:
        base = ["Berçário", "Maternal I", "Maternal II"]
        if self.tipo == "EDI":
            base += ["Pré-Escola I", "Pré-Escola II"]
        return base


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlmb = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def grupamento_por_nascimento(nascimento: date, ref: date = INICIO_ANO_LETIVO) -> str:
    meses = (ref.year - nascimento.year) * 12 + (ref.month - nascimento.month)
    if meses < 12:
        return "Berçário"
    if meses < 24:
        return "Maternal I"
    if meses < 36:
        return "Maternal II"
    if meses < 48:
        return "Pré-Escola I"
    return "Pré-Escola II"


# ---------------------------------------------------------------------------
# Amostra de unidades. Coordenadas em nível de bairro (aproximadas).
# ---------------------------------------------------------------------------
_LINHAS: list[tuple] = [
    # codigo, nome, tipo, cre, bairro, endereco, lat, lon
    ("CRE02-0117", "Creche Municipal Zilda Arns", "Creche Municipal", 2, "Tijuca", "Rua Conde de Bonfim, 400 — Tijuca", -22.9245, -43.2336),
    ("CRE02-0142", "EDI Anísio Teixeira", "EDI", 2, "Vila Isabel", "Boulevard 28 de Setembro, 210 — Vila Isabel", -22.9163, -43.2478),
    ("CRE02-0088", "Creche Municipal Paulo Freire", "Creche Municipal", 2, "Maracanã", "Rua São Francisco Xavier, 524 — Maracanã", -22.9126, -43.2270),
    ("CRE02-0203", "EDI Darcy Ribeiro", "EDI", 2, "Grajaú", "Rua Barão do Bom Retiro, 1200 — Grajaú", -22.9231, -43.2596),
    ("CRE04-0051", "Creche Municipal Tarsila do Amaral", "Creche Municipal", 4, "Botafogo", "Rua Voluntários da Pátria, 190 — Botafogo", -22.9515, -43.1837),
    ("CRE04-0067", "EDI Cora Coralina", "EDI", 4, "Flamengo", "Rua Marquês de Abrantes, 80 — Flamengo", -22.9324, -43.1755),
    ("CRE04-0072", "Creche Municipal Cecília Meireles", "Creche Municipal", 4, "Laranjeiras", "Rua das Laranjeiras, 400 — Laranjeiras", -22.9345, -43.1875),
    ("CRE04-0090", "Creche Municipal Santa Teresa", "Creche Municipal", 4, "Santa Teresa", "Rua Almirante Alexandrino, 1100 — Santa Teresa", -22.9200, -43.1877),
    ("CRE04-0110", "EDI Portinari", "EDI", 4, "Catete", "Rua do Catete, 310 — Catete", -22.9268, -43.1780),
    ("CRE04-0121", "Creche Municipal Copacabana", "Creche Municipal", 4, "Copacabana", "Rua Barata Ribeiro, 500 — Copacabana", -22.9711, -43.1868),
    ("CRE04-0133", "EDI Vinícius de Moraes", "EDI", 4, "Ipanema", "Rua Prudente de Moraes, 300 — Ipanema", -22.9838, -43.2048),
    ("CRE04-0140", "Creche Municipal Leblon", "Creche Municipal", 4, "Leblon", "Rua Dias Ferreira, 100 — Leblon", -22.9838, -43.2237),
    ("CRE04-0155", "EDI Rubem Braga", "EDI", 4, "Gávea", "Rua Marquês de São Vicente, 200 — Gávea", -22.9770, -43.2323),
    ("CRE03-0044", "Creche Municipal São Cristóvão", "Creche Municipal", 3, "São Cristóvão", "Rua São Luiz Gonzaga, 300 — São Cristóvão", -22.8975, -43.2225),
    ("CRE07-0061", "EDI Nise da Silveira", "EDI", 7, "Méier", "Rua Dias da Cruz, 400 — Méier", -22.9024, -43.2794),
    ("CRE07-0078", "Creche Municipal Engenho de Dentro", "Creche Municipal", 7, "Engenho de Dentro", "Rua Ana Néri, 150 — Engenho de Dentro", -22.8876, -43.2913),
    ("CRE07-0092", "EDI Clarice Lispector", "EDI", 7, "Cascadura", "Rua Carolina Machado, 500 — Cascadura", -22.8845, -43.3260),
    ("CRE07-0103", "Creche Municipal Madureira", "Creche Municipal", 7, "Madureira", "Estrada do Portela, 200 — Madureira", -22.8730, -43.3390),
    ("CRE06-0035", "EDI Milton Santos", "EDI", 6, "Irajá", "Av. Monsenhor Félix, 300 — Irajá", -22.8290, -43.3270),
    ("CRE05-0048", "Creche Municipal Penha", "Creche Municipal", 5, "Penha", "Rua do Cajá, 120 — Penha", -22.8430, -43.2790),
    ("CRE05-0059", "EDI Ramos", "EDI", 5, "Ramos", "Rua Uranos, 900 — Ramos", -22.8500, -43.2560),
    ("CRE03-0071", "Creche Municipal Ilha do Governador", "Creche Municipal", 3, "Cocotá", "Estrada do Galeão, 800 — Ilha do Governador", -22.8050, -43.1900),
    ("CRE10-0022", "EDI Oscar Niemeyer", "EDI", 10, "Barra da Tijuca", "Av. das Américas, 5000 — Barra da Tijuca", -23.0000, -43.3650),
    ("CRE10-0031", "Creche Municipal Recreio", "Creche Municipal", 10, "Recreio dos Bandeirantes", "Av. das Américas, 16000 — Recreio", -23.0250, -43.4680),
    ("CRE10-0040", "EDI Freguesia", "EDI", 10, "Freguesia (Jacarepaguá)", "Estrada dos Três Rios, 400 — Freguesia", -22.9380, -43.3430),
    ("CRE10-0052", "Creche Municipal Taquara", "Creche Municipal", 10, "Taquara", "Estrada do Tindiba, 600 — Taquara", -22.9200, -43.3830),
    ("CRE09-0018", "EDI Campo Grande", "EDI", 9, "Campo Grande", "Rua Coronel Agostinho, 200 — Campo Grande", -22.9020, -43.5610),
    ("CRE09-0027", "Creche Municipal Santa Cruz", "Creche Municipal", 9, "Santa Cruz", "Rua Felipe Cardoso, 300 — Santa Cruz", -22.9160, -43.6840),
    ("CRE08-0014", "EDI Bangu", "EDI", 8, "Bangu", "Rua Fonseca, 400 — Bangu", -22.8760, -43.4650),
    ("CRE08-0025", "Creche Municipal Realengo", "Creche Municipal", 8, "Realengo", "Rua Marechal Soares de Andréa, 100 — Realengo", -22.8790, -43.4290),
    ("CRE10-0063", "Creche Municipal Guaratiba", "Creche Municipal", 10, "Guaratiba", "Estrada da Matriz, 200 — Guaratiba", -23.0560, -43.5940),
]

UNIDADES: list[Unidade] = [Unidade(*linha) for linha in _LINHAS]
POR_CODIGO: dict[str, Unidade] = {u.codigo: u for u in UNIDADES}

BAIRROS = sorted({u.bairro for u in UNIDADES})

# Totais da amostra no ano de referência (para exibir "a base tem X dados").
TOTAL_UNIDADES = len(UNIDADES)
TOTAL_VAGAS_ANO_ANTERIOR = sum(u.vagas_ofertadas_ano_anterior for u in UNIDADES)
TOTAL_INSCRITOS_ANO_ANTERIOR = sum(u.inscritos_ano_anterior for u in UNIDADES)


def centroide_bairro(bairro: str) -> tuple[float, float] | None:
    pts = [(u.lat, u.lon) for u in UNIDADES if u.bairro == bairro]
    if not pts:
        return None
    return (sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts))


# ---------------------------------------------------------------------------
# Ranqueamento
# ---------------------------------------------------------------------------
@dataclass
class UnidadeRanqueada:
    unidade: Unidade
    distancia_km: float | None
    candidatos_por_vaga: float  # base 2025
    score: float
    motivo: str


def _norm(valor: float, menor: float, maior: float) -> float:
    if maior <= menor:
        return 0.5
    return (valor - menor) / (maior - menor)


def ranquear(
    criterio: str,
    grupamento: str,
    ref: tuple[float, float] | None,
) -> list[UnidadeRanqueada]:
    """criterio: 'proximidade' | 'agilidade'.

    'agilidade' usa a concorrência do ano anterior (inscritos ÷ vagas de 2025)
    como indicação de onde a chance de alocação rápida é maior.
    """
    elegiveis = [u for u in UNIDADES if grupamento in u.grupamentos]

    dists = {
        u.codigo: (haversine_km(ref[0], ref[1], u.lat, u.lon) if ref else None)
        for u in elegiveis
    }
    razoes = {u.codigo: u.candidatos_por_vaga_ano_anterior for u in elegiveis}

    r_vals = list(razoes.values()) or [1.0]
    r_min, r_max = min(r_vals), max(r_vals)

    dist_num = [d for d in dists.values() if d is not None]
    d_min, d_max = (min(dist_num), max(dist_num)) if dist_num else (0.0, 1.0)

    resultado: list[UnidadeRanqueada] = []
    for u in elegiveis:
        d = dists[u.codigo]
        razao = razoes[u.codigo]
        chance = 1.0 - _norm(razao, r_min, r_max)  # menor concorrência -> maior
        perto = 0.5 if d is None else 1.0 - _norm(d, d_min, d_max)

        base_2025 = (
            f"Em 2025: {u.vagas_ofertadas_ano_anterior} vagas para "
            f"{u.inscritos_ano_anterior} inscritos (~{razao:.1f} por vaga)."
        )
        if criterio == "proximidade":
            score = 0.80 * perto + 0.20 * chance
            if d is not None and d <= 1.0:
                motivo = f"A ~{d:.1f} km do endereço informado — dá para ir a pé."
            elif d is not None:
                motivo = f"A ~{d:.1f} km do endereço informado."
            else:
                motivo = "No bairro informado."
        else:  # agilidade
            score = 0.85 * chance + 0.15 * perto
            motivo = base_2025

        resultado.append(UnidadeRanqueada(u, d, razao, score, motivo))

    if criterio == "proximidade":
        resultado.sort(key=lambda r: (r.distancia_km if r.distancia_km is not None else 1e9, -r.score))
    else:
        resultado.sort(key=lambda r: (r.candidatos_por_vaga, -r.score))
    return resultado
